<?php
class Config{
  const DB = [
    "host" => "localhost",
    "username" => "id9864931_nalesevic",
    "password" => "taxi123",
    "scheme" => "id9864931_taxi"
  ];
  const JWT_SECRET = "taxitaxi";
}
?>
